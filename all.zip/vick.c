#include <arpa/inet.h> // inet_addr()
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h> // bzero()
#include <sys/socket.h>
#include <unistd.h> // read(), write(), close()
#include <netinet/tcp.h>
#define MAX 1552
#define SA struct sockaddr

#pragma pack(1)
struct udp_packet3 {
    int port;
    char ip[12];
    char topic[50];
    unsigned int type;
    char payload[1552];
};
#pragma pack()

#pragma pack(1)
struct udp_packet0 {
    int port;
    char ip[12];
    char topic[50];
    unsigned int type;
    int32_t payload;
};
#pragma pack()

#pragma pack(1)
struct udp_packet1 {
    int port;
    char ip[12];
    char topic[50];
    unsigned int type;
    double payload;
};
#pragma pack()

#pragma pack(1)
struct udp_packet2 {
    int port;
    char ip[12];
    char topic[50];
    unsigned int type;
    double payload;
};
#pragma pack()

void error(const char *msg){
    perror(msg);
    exit(1);
}

int main(int argc, char **argv)
{

	setvbuf(stdout, NULL, _IONBF, BUFSIZ);
	int sockfd_server;
	struct sockaddr_in servaddr;
	fd_set master, readfds;

	// aici se trimite conexiunea clientului 
    char newbuff[MAX];
	int offset = 0;
	bzero(newbuff, MAX);
	
	memcpy(newbuff, argv[1], strlen(argv[1]));
	offset += strlen(argv[1]);
	newbuff[offset] = ' ';
	offset++;

	memcpy(newbuff + offset, argv[2], strlen(argv[2]));
	offset += strlen(argv[2]);
	newbuff[offset] = ':';
	offset++;

	memcpy(newbuff + offset, argv[3], strlen(argv[3]));
	offset += strlen(argv[3]);
	newbuff[offset] = '.';
	offset++;
	
	newbuff[offset] = '\0';
	offset++;
	// aici se termina bufferul pt conexiunea clientului


	sockfd_server = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd_server < 0) {
		error("socket creation failed"); 
	}

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	inet_aton(argv[2], &servaddr.sin_addr);
	servaddr.sin_port = htons(atoi(argv[3]));

	if(connect(sockfd_server, (SA*)&servaddr, sizeof(servaddr)) < 0){
		error("couldn't connect");
	}
	
	send(sockfd_server, newbuff, offset, 0);

	int flag = 1;
	if(setsockopt(sockfd_server, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(int)) < 0){
		error("Error naggle");
	}

	FD_ZERO(&master);
	FD_SET(sockfd_server, &master);
	FD_SET(0, &master);

	for(; ;){
		readfds = master;
		if (select(sockfd_server + 1, &readfds, NULL, NULL, NULL) == -1){
            perror("select");
            exit(4); 
        }

		if(FD_ISSET(0, &readfds)){

			char buff[MAX]; 
			bzero(buff, MAX);
            fgets(buff, MAX - 1, stdin);
                    
        	if(strncmp(buff, "exit", 4) == 0){
                break;
            }
			else{
				if(strncmp(buff, "subscribe", 9) == 0){
					char newbuffmsj[72];
					bzero(newbuffmsj, 72);
					
					strcat(newbuffmsj, "subscribe^");
					strcat(newbuffmsj, argv[1]);
					

					strcat(newbuffmsj, "^");
					strcat(newbuffmsj, buff + 10);
					
					send(sockfd_server, newbuffmsj, strlen(newbuffmsj) + 1, 0);
					printf("Subscribed to topic %s", buff + 10);
				} else if(strncmp(buff, "unsubscribe", 11) == 0){
					char newbuffmsj[74];
					bzero(newbuffmsj, 74);

					strcat(newbuffmsj, "unsubscribe^");
					strcat(newbuffmsj, argv[1]);
					

					strcat(newbuffmsj, "^");
					strcat(newbuffmsj, buff + 12);
					
					send(sockfd_server, newbuffmsj, strlen(newbuffmsj) + 1, 0);
					printf("Unsubscribed from topic %s\n", buff + 12);
				}
				
			}
		}
		if(FD_ISSET(sockfd_server, &readfds)){
			char buff[3000]; 
			bzero(buff, 3000);
			if (recv(sockfd_server, buff, 3000, 0) == 0) {
				break; 
			}
			
			if((char) *buff == '0'){
				struct udp_packet0 *packet_ptr = (struct udp_packet0 *)(buff+1);

				int port = packet_ptr->port; 
			
				char ip[12];
				bzero(ip, 12);
				memcpy(ip, packet_ptr->ip, sizeof(packet_ptr->ip));

				char topic[50];
				bzero(topic, 50);
				memcpy(topic, packet_ptr->topic, sizeof(packet_ptr->topic));
				
				// uint8_t type = packet_ptr->type;
				
				printf("%s:%d - %s - INT - %d\n", ip, port, topic, packet_ptr->payload);
				
			}

			else if((char) *buff == '1'){
				struct udp_packet1 *packet_ptr = (struct udp_packet1 *)(buff+1);

				int port = packet_ptr->port;

				char ip[12];
				bzero(ip, 12);
				memcpy(ip, packet_ptr->ip, sizeof(packet_ptr->ip));

				char topic[50];
				bzero(topic, 50);
				memcpy(topic, packet_ptr->topic, sizeof(packet_ptr->topic));
				
				// uint8_t type = packet_ptr->type;

				printf("%s:%d - %s - SHORT-REAL - %.2f\n", ip, port, topic,  packet_ptr->payload);
				
			}

			else if((char) *buff == '2'){
				struct udp_packet2 *packet_ptr = (struct udp_packet2 *)(buff+1);

				int port = packet_ptr->port;

				char ip[12];
				bzero(ip, 12);
				memcpy(ip, packet_ptr->ip, sizeof(packet_ptr->ip));

				char topic[50];
				bzero(topic, 50);
				memcpy(topic, packet_ptr->topic, sizeof(packet_ptr->topic));
				
				// uint8_t type = packet_ptr->type;

				printf("%s:%d - %s - FLOAT - %f\n", ip, port, topic,  packet_ptr->payload);
				
			}
			else if((char) *buff == '3'){
				struct udp_packet3 *packet_ptr = (struct udp_packet3 *)(buff+1);

				int port = packet_ptr->port;

				char ip[12];
				bzero(ip, 12);
				memcpy(ip, packet_ptr->ip, sizeof(packet_ptr->ip));

				char topic[50];
				bzero(topic, 50);
				memcpy(topic, packet_ptr->topic, sizeof(packet_ptr->topic));
				
				// uint8_t type = packet_ptr->type;
				packet_ptr->payload[1499] = '\0';

				printf("%s:%d - %s - STRING - %s\n", ip, port, topic,  packet_ptr->payload);
				
			}
			

		}

	}

	// function for chat
	// func(sockfd_server);

	// close the socket
	close(sockfd_server);
}