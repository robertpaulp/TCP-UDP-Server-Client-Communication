# Homework 2

I. Server

Serverul este implementat dupa structura laboratorului, dar adaptat la cerinta temei. In poll_fds sunt adaugate initial trei valori (tcp_connection, udp_connection si stdin), iar in timpul rularii se adauga si se elimina in functie de evenimente.
Exista trei cazuri : -> am primit o cerere de conexiune tcp, o acceptam si o adaugam in poll_fds si asteptam client_id-ul
                     -> am primit o cerere de conexiune udp, o acceptam, parcurgem lista de clienti si topicurile la care sunt abonati si trimitem mesajele corespunzatoare
                     -> am primit un mesaj de la un client -> daca este de tip "ID", verificam daca acesta se afla in lista noastra de abonati activi si daca nu, il adaugam
                                                           -> daca este de tip "subscribe", adaugam topicul la lista de topicuri la care este abonat clientul cu id respectiv
                                                           -> daca este de tip "unsubscribe", eliminam topicul din lista de topicuri

Deoarece am considerat ca serverul este cel care trebuie sa formeze pachetele sub un anumit format, implementarea udp este facuta in acesta, iar clientul doar afiseaza mesajele primite.

```
struct client_id_table {
    char id[10];
    int socket_fd;
};
```
`-> structura retine id-ul clientului care este activ si socketul corespunzator

map<char *, vector<string>> topic_map; -> un map care retine id-ul clientului sub forma de cheie si topicurile la care este abonat

Implementarea de topic_map si client_id_table este separata pentru a facilita salvarea informatiilor chiar daca clientul se deconecteaza.
Implementare de wildcard pentru topicuri urmeaza o metoda greedy. Parcurgem caracter cu caracter si verificam daca se potrivesc. Daca se intalneste un caracter '*', se salveaza pozitia acestuia din pattern si se salveaza si pozitia ultimului caracter verificat din text. In momentul in care 'last_star_index' este diferit de -1 si caracterele sunt diferite (adica parcurgere verifica, de ex, 'precis' cu '/', urmatorul caracter din pattern) iteratia continua pana cand se gaseste urmatorul caracter asemanator.
In cazul caracterului '+', stim ca acesta accepta doar un singur nivel, asa ca acesta merge pana gaseste primul '/'. Daca se afla pe ultima pozitie acesta creste pattern_idx pana la sfarsitul patternului.

II. Client

Clientul prezinta o structura simpla, acesta avand doar doi file descriptori, unul pentru tcp si unul pentru a comunica cu stdin. Daca subscriberul primeste un mesaj de la server, acesta il afiseaza.
In cazul in care se citeste de la tastatura, acesta trimite mesajul catre server si afiseaza pe ecran mesajele aferente.